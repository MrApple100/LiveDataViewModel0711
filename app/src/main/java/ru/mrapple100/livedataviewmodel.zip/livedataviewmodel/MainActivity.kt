package ru.mrapple100.livedataviewmodel

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil
import ru.mrapple100.livedataviewmodel.databinding.ActivityMainBinding
//https://codeshare.io/64Jkko
class MainActivity : AppCompatActivity() {

    val repo = ListRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //отфильтрованный список
        var goodList = repo.getList()

        val binding: ActivityMainBinding = DataBindingUtil.setContentView(this,R.layout.activity_main)

        binding.SearchET.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                val keyword = p0.toString()
                goodList = repo.getList().filterListTitle(keyword)
                binding.ListTV.text = goodList.toString()
            }
        })

        binding.ListTV.text = goodList.toString()


        setContentView(binding.root)

    }

    fun ArrayList<Film>.filterListTitle(keyword:String): ArrayList<Film> {
        return this.filter{it ->  it.title.lowercase().startsWith(keyword.lowercase())} as ArrayList
    }
    fun ArrayList<Film>.filterListYear(keyword:String): ArrayList<Film>{
        //">2005"  "<2020"
        return this.filter{it ->
            val char = keyword[0]
            if (char == '>'){
                return@filter (it.year > (keyword.split(">")[1].toInt()))
            }else if(char == '<'){
                return@filter it.year < (keyword.split("<")[1].toInt())
            }
            return@filter false
        } as ArrayList<Film>
    }
    fun ArrayList<Film>.sortListDirector(keyword:String): ArrayList<Film> {
        //>  < лексикографически
        if(keyword.equals(">")) {

            return this.sortedBy { it -> it.director }.toList() as ArrayList<Film>
        }else{
            return this.sortedByDescending { it -> it.director } as ArrayList<Film>
        }
    }






}